/*
  ==============================================================================

    This file was auto-generated!

    Main.cpp

    It contains the basic startup code for a JUCE application.

  ==============================================================================
*/

#include "../JuceLibraryCode/JuceHeader.h"
#include "MainComponent.h"

//==============================================================================
class OtoDecksApplication : public JUCEApplication
{
public:
    //==============================================================================
    OtoDecksApplication() {}

    /** Returns the application name from project metadata. */
    const String getApplicationName() override { return ProjectInfo::projectName; }

    /** Returns the application version string from project metadata. */
    const String getApplicationVersion() override { return ProjectInfo::versionString; }

    /** Returns true � multiple instances of OtoDecks are permitted. */
    bool moreThanOneInstanceAllowed() override { return true; }

    //==============================================================================
    /** Creates the main window and shows it.
        @param commandLine  Command-line arguments passed at launch (unused). */
    void initialise(const String& commandLine) override
    {
        // This method is where you should put your application's initialisation code..

        mainWindow.reset(new MainWindow(getApplicationName()));
    }

    /** Destroys the main window and releases all resources. */
    void shutdown() override
    {
        // Add your application's shutdown code here..

        mainWindow = nullptr; // (deletes our window)
    }

    //==============================================================================
    /** Called by the OS when the application is asked to close. Calls quit(). */
    void systemRequestedQuit() override
    {
        // This is called when the app is being asked to quit: you can ignore this
        // request and let the app carry on running, or call quit() to allow the app to close.
        quit();
    }

    /** Called when a second instance of OtoDecks is launched. Not used.
        @param commandLine  Arguments passed to the second instance. */
    void anotherInstanceStarted(const String& commandLine) override
    {
        // When another instance of the app is launched while this one is running,
        // this method is invoked, and the commandLine parameter tells you what
        // the other instance's command-line arguments were.
    }

    //==============================================================================
    /*
        This class implements the desktop window that contains an instance of
        our MainComponent class.
    */
    class MainWindow : public DocumentWindow
    {
    public:
        /** Creates the window, sets a native title bar, and shows MainComponent.
            On mobile the window is full-screen; on desktop it is resizable.
            @param name  Title shown in the window's title bar. */
        MainWindow(String name) : DocumentWindow(name,
            Desktop::getInstance().getDefaultLookAndFeel()
            .findColour(ResizableWindow::backgroundColourId),
            DocumentWindow::allButtons)
        {
            setUsingNativeTitleBar(true);
            setContentOwned(new MainComponent(), true);

#if JUCE_IOS || JUCE_ANDROID
            setFullScreen(true);
#else
            setResizable(true, true);
            centreWithSize(getWidth(), getHeight());
#endif

            setVisible(true);
        }

        /** Requests application quit when the user clicks the window's close button. */
        void closeButtonPressed() override
        {
            // This is called when the user tries to close this window. Here, we'll just
            // ask the app to quit when this happens, but you can change this to do
            // whatever you need.
            JUCEApplication::getInstance()->systemRequestedQuit();
        }

        /* Note: Be careful if you override any DocumentWindow methods - the base
           class uses a lot of them, so by overriding you might break its functionality.
           It's best to do all your work in your content component instead, but if
           you really have to override any DocumentWindow methods, make sure your
           subclass also calls the superclass's method.
        */

    private:
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MainWindow)
    };

private:
    std::unique_ptr<MainWindow> mainWindow;
};

//==============================================================================
// This macro generates the main() routine that launches the app.
START_JUCE_APPLICATION(OtoDecksApplication)
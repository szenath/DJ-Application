/*
  ==============================================================================

    DeckGUI.cpp
    Created: 13 Mar 2020 6:44:48pm
    Author:  matthew

  ==============================================================================
*/

#include "DeckGUI.h"
#include "WaveformDisplay.h"

//==============================================================================
DeckGUI::TransportToggleButton::TransportToggleButton()
    : juce::Button("TransportToggleButton")
{
}

void DeckGUI::TransportToggleButton::setToggled(bool shouldBeToggled)
{
    toggled = shouldBeToggled;
    repaint();
}

void DeckGUI::TransportToggleButton::paintButton(juce::Graphics& g, bool isMouseOver, bool isButtonDown)
{
    auto bounds = getLocalBounds().toFloat();
    const float corner = 8.0f;

    // Button background (let LookAndFeel handle colours)
    auto base = findColour(juce::TextButton::buttonColourId);
    if (isButtonDown) base = base.darker(0.15f);
    else if (isMouseOver) base = base.brighter(0.08f);

    g.setColour(base);
    g.fillRoundedRectangle(bounds, corner);

    // Inner bevel (simple 3D)
    g.setColour(juce::Colours::white.withAlpha(0.10f));
    g.drawRoundedRectangle(bounds.reduced(1.0f), corner - 1.0f, 1.5f);
    g.setColour(juce::Colours::black.withAlpha(0.35f));
    g.drawRoundedRectangle(bounds.reduced(0.5f), corner - 0.5f, 1.0f);

    // Icon
    g.setColour(findColour(juce::TextButton::textColourOnId));

    const float iconPad = 10.0f;
    auto iconArea = bounds.reduced(iconPad);

    if (!toggled)
    {
        // Play triangle
        juce::Path p;
        p.addTriangle(iconArea.getX(),
            iconArea.getY(),
            iconArea.getRight(),
            iconArea.getCentreY(),
            iconArea.getX(),
            iconArea.getBottom());
        g.fillPath(p);
    }
    else
    {
        // Pause bars
        auto w = iconArea.getWidth();
        auto h = iconArea.getHeight();
        auto barW = w * 0.30f;
        auto gap = w * 0.12f;

        juce::Rectangle<float> left(iconArea.getX(), iconArea.getY(), barW, h);
        juce::Rectangle<float> right(iconArea.getX() + barW + gap, iconArea.getY(), barW, h);

        g.fillRoundedRectangle(left, 2.0f);
        g.fillRoundedRectangle(right, 2.0f);
    }
}

//==============================================================================
DeckGUI::DeckGUI(DJAudioPlayer* _player,
    WaveformDisplay* _linkedWaveform,
    std::function<void(const juce::File&)> _onTrackLoaded)
    : player(_player),
    linkedWaveform(_linkedWaveform),
    onTrackLoaded(std::move(_onTrackLoaded))
{
    addAndMakeVisible(playPauseButton);
    addAndMakeVisible(loadButton);

    addAndMakeVisible(volSlider);
    addAndMakeVisible(speedSlider);

    addAndMakeVisible(speedValueLabel);
    addAndMakeVisible(volValueLabel);

    playPauseButton.addListener(this);
    loadButton.addListener(this);

    volSlider.addListener(this);
    speedSlider.addListener(this);

    // Sliders
    volSlider.setRange(0.0, 1.0, 0.001);
    speedSlider.setRange(0.5, 2.0, 0.001);  // 1.0 = normal

    volSlider.setValue(0.8);
    speedSlider.setValue(1.0);

    volSlider.setSliderStyle(juce::Slider::LinearVertical);
    speedSlider.setSliderStyle(juce::Slider::LinearVertical);

    volSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    speedSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);

    // Labels (small numeric readout like BPM/speed %)
    auto initLabel = [](juce::Label& l)
        {
            l.setJustificationType(juce::Justification::centred);
            l.setFont(juce::Font(13.0f, juce::Font::bold));
            l.setColour(juce::Label::textColourId, juce::Colours::white.withAlpha(0.85f));
        };

    initLabel(speedValueLabel);
    initLabel(volValueLabel);

    speedValueLabel.setText("1.00x", juce::dontSendNotification);
    volValueLabel.setText("0.80", juce::dontSendNotification);

    // Make load button compact
    loadButton.setClickingTogglesState(false);

    startTimerHz(30);
}

DeckGUI::~DeckGUI()
{
    stopTimer();
}

void DeckGUI::paint(juce::Graphics& g)
{
    // Background handled by parent LookAndFeel; keep this subtle
    g.setColour(juce::Colours::transparentBlack);

    // Small captions by sliders
    g.setColour(juce::Colours::white.withAlpha(0.55f));
    g.setFont(12.0f);

    // Note icon near volume
    auto left = volSlider.getBounds().toFloat();
    g.drawText("VOL", left.withY(left.getY() - 18).withHeight(16).toNearestInt(),
        juce::Justification::centred, false);

    auto right = speedSlider.getBounds().toFloat();
    g.drawText("SPD", right.withY(right.getY() - 18).withHeight(16).toNearestInt(),
        juce::Justification::centred, false);
}

void DeckGUI::resized()
{
    const int pad = 10;

    // Transport row (small)
    const int transportH = 44;
    const int transportW = 84;

    playPauseButton.setBounds(pad, pad, transportW, transportH);
    loadButton.setBounds(pad + transportW + 8, pad, 86, transportH);

    // Sliders: volume outer edge, speed inner edge
    const int sliderTop = pad + transportH + 10;
    const int sliderBottomPad = 12;
    const int sliderH = getHeight() - sliderTop - sliderBottomPad;

    const int sliderW = 34;

    // Decide which side this deck is (left deck sits left of centre; right deck sits right)
    const bool isLeftDeck = (getX() < getParentWidth() / 2);

    if (isLeftDeck)
    {
        // Volume on far left
        volValueLabel.setBounds(pad, sliderTop, sliderW, 18);
        volSlider.setBounds(pad, sliderTop + 20, sliderW, sliderH - 20);

        // Speed on far right (inner edge)
        speedValueLabel.setBounds(getWidth() - pad - sliderW, sliderTop, sliderW, 18);
        speedSlider.setBounds(getWidth() - pad - sliderW, sliderTop + 20, sliderW, sliderH - 20);
    }
    else
    {
        // Volume on far right
        volValueLabel.setBounds(getWidth() - pad - sliderW, sliderTop, sliderW, 18);
        volSlider.setBounds(getWidth() - pad - sliderW, sliderTop + 20, sliderW, sliderH - 20);

        // Speed on far left (inner edge)
        speedValueLabel.setBounds(pad, sliderTop, sliderW, 18);
        speedSlider.setBounds(pad, sliderTop + 20, sliderW, sliderH - 20);
    }
}

void DeckGUI::buttonClicked(juce::Button* button)
{
    if (button == &playPauseButton)
    {
        if (player == nullptr) return;

        const bool nowPlaying = !player->isPlaying();

        if (nowPlaying) player->start();
        else player->stop();

        playPauseButton.setToggled(nowPlaying);
        return;
    }

    if (button == &loadButton)
    {
        auto flags = juce::FileBrowserComponent::canSelectFiles;

        fChooser.launchAsync(flags, [this](const juce::FileChooser& chooser)
            {
                auto chosen = chooser.getResult();
                if (!chosen.existsAsFile() || player == nullptr)
                    return;

                player->loadURL(juce::URL{ chosen });

                if (linkedWaveform != nullptr)
                    linkedWaveform->loadURL(juce::URL{ chosen });

                if (onTrackLoaded)
                    onTrackLoaded(chosen);

                // Reset play button state visually
                playPauseButton.setToggled(false);
            });
    }
}

void DeckGUI::sliderValueChanged(juce::Slider* slider)
{
    if (player == nullptr) return;

    if (slider == &volSlider)
    {
        player->setGain(slider->getValue());
        volValueLabel.setText(juce::String(slider->getValue(), 2), juce::dontSendNotification);
    }
    else if (slider == &speedSlider)
    {
        player->setSpeed(slider->getValue());
        speedValueLabel.setText(juce::String(slider->getValue(), 2) + "x", juce::dontSendNotification);
    }
}

bool DeckGUI::isInterestedInFileDrag(const juce::StringArray& files)
{
    return files.size() == 1;
}

void DeckGUI::filesDropped(const juce::StringArray& files, int, int)
{
    if (files.size() != 1 || player == nullptr) return;

    juce::File f(files[0]);
    if (!f.existsAsFile()) return;

    player->loadURL(juce::URL{ f });

    if (linkedWaveform != nullptr)
        linkedWaveform->loadURL(juce::URL{ f });

    if (onTrackLoaded)
        onTrackLoaded(f);

    playPauseButton.setToggled(false);
}

void DeckGUI::timerCallback()
{
    // Keep the play/pause button in sync if user stops elsewhere
    if (player != nullptr)
        playPauseButton.setToggled(player->isPlaying());
}

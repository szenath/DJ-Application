/*
  ==============================================================================

    DJLookAndFeel.h
    Created: 6 Feb 2026 12:07:31am
    Author:  szena

  ==============================================================================
*/
#pragma once
#include <JuceHeader.h>

class DJLookAndFeel : public juce::LookAndFeel_V4
{
public:
    DJLookAndFeel()
    {
        setColour(juce::ResizableWindow::backgroundColourId, juce::Colour(0xFF2B3A41));

        setColour(juce::Slider::thumbColourId, juce::Colour(0xFF5EC5FF));
        setColour(juce::Slider::trackColourId, juce::Colour(0xFF42555E));
        setColour(juce::Slider::backgroundColourId, juce::Colour(0xFF1F2A30));

        setColour(juce::TextButton::buttonColourId, juce::Colour(0xFF2B3A41));
        setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    }

    void drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
        float sliderPos, float minSliderPos, float maxSliderPos,
        const juce::Slider::SliderStyle style, juce::Slider& slider) override
    {
        const auto trackBg = slider.findColour(juce::Slider::backgroundColourId);
        const auto trackFg = slider.findColour(juce::Slider::trackColourId);
        const auto thumbC = slider.findColour(juce::Slider::thumbColourId);

        if (style == juce::Slider::LinearVertical)
        {
            auto trackX = x + width / 2.0f - 4.0f;
            auto track = juce::Rectangle<float>(trackX, (float)y + 4.0f, 8.0f, (float)height - 8.0f);

            g.setColour(juce::Colours::black.withAlpha(0.28f));
            g.fillRoundedRectangle(track.translated(1.6f, 1.6f), 4.0f);

            g.setColour(trackBg);
            g.fillRoundedRectangle(track, 4.0f);

            g.setColour(juce::Colours::white.withAlpha(0.06f));
            g.drawRoundedRectangle(track.reduced(1.0f), 3.0f, 1.0f);

            auto thumb = juce::Rectangle<float>(track.getX() - 10.0f, sliderPos - 10.0f,
                track.getWidth() + 20.0f, 20.0f);

            g.setColour(juce::Colours::black.withAlpha(0.38f));
            g.fillRoundedRectangle(thumb.translated(1.6f, 1.6f), 6.0f);

            juce::ColourGradient grad(thumbC.brighter(0.25f), thumb.getCentreX(), thumb.getY(),
                thumbC.darker(0.30f), thumb.getCentreX(), thumb.getBottom(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(thumb, 6.0f);

            g.setColour(juce::Colours::white.withAlpha(0.10f));
            g.drawRoundedRectangle(thumb, 6.0f, 1.0f);

            g.setColour(juce::Colours::black.withAlpha(0.22f));
            g.drawLine(thumb.getX() + 6.0f, thumb.getCentreY(), thumb.getRight() - 6.0f, thumb.getCentreY(), 1.0f);
            return;
        }

        if (style == juce::Slider::LinearHorizontal)
        {
            // Better 2-sided crossfader track (left+right clearly visible)
            auto track = juce::Rectangle<float>((float)x + 4.0f,
                (float)y + height / 2.0f - 5.0f,
                (float)width - 8.0f,
                10.0f);

            // Shadow
            g.setColour(juce::Colours::black.withAlpha(0.30f));
            g.fillRoundedRectangle(track.translated(1.6f, 1.6f), 5.0f);

            // Base track
            g.setColour(trackBg);
            g.fillRoundedRectangle(track, 5.0f);

            // Inner highlight
            g.setColour(juce::Colours::white.withAlpha(0.06f));
            g.drawRoundedRectangle(track.reduced(1.0f), 4.0f, 1.0f);

            // Left fill (darker)
            auto left = track.withRight(sliderPos);
            g.setColour(trackFg.darker(0.15f).withAlpha(0.95f));
            g.fillRoundedRectangle(left, 5.0f);

            // Right fill (BRIGHTER + more opaque so it’s obvious)
            auto right = track.withLeft(sliderPos);
            g.setColour(trackFg.brighter(0.35f).withAlpha(0.85f));
            g.fillRoundedRectangle(right, 5.0f);

            // Centre marker line (DJ-style)
            auto cx = track.getCentreX();
            g.setColour(juce::Colours::white.withAlpha(0.22f));
            g.drawLine(cx, track.getY() - 6.0f, cx, track.getBottom() + 6.0f, 1.5f);

            // Thumb (3D)
            auto thumb = juce::Rectangle<float>(sliderPos - 12.0f,
                track.getCentreY() - 14.0f,
                24.0f,
                28.0f);

            g.setColour(juce::Colours::black.withAlpha(0.40f));
            g.fillRoundedRectangle(thumb.translated(1.6f, 1.6f), 7.0f);

            juce::ColourGradient grad(thumbC.brighter(0.25f), thumb.getX(), thumb.getY(),
                thumbC.darker(0.35f), thumb.getRight(), thumb.getBottom(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(thumb, 7.0f);

            g.setColour(juce::Colours::white.withAlpha(0.12f));
            g.drawRoundedRectangle(thumb, 7.0f, 1.0f);

            // Grip
            g.setColour(juce::Colours::black.withAlpha(0.22f));
            g.drawLine(thumb.getCentreX(), thumb.getY() + 6.0f, thumb.getCentreX(), thumb.getBottom() - 6.0f, 1.2f);

            return;
        }

        juce::LookAndFeel_V4::drawLinearSlider(g, x, y, width, height,
            sliderPos, minSliderPos, maxSliderPos,
            style, slider);
    }

    void drawButtonBackground(juce::Graphics& g, juce::Button& button,
        const juce::Colour& backgroundColour,
        bool isMouseOverButton, bool isButtonDown) override
    {
        auto bounds = button.getLocalBounds().toFloat().reduced(1.0f);

        auto base = backgroundColour;
        if (isButtonDown)           base = base.darker(0.25f);
        else if (isMouseOverButton) base = base.brighter(0.08f);

        g.setColour(juce::Colours::black.withAlpha(0.25f));
        g.fillRoundedRectangle(bounds.translated(1.5f, 1.5f), 10.0f);

        juce::ColourGradient grad(base.brighter(0.15f), bounds.getX(), bounds.getY(),
            base.darker(0.25f), bounds.getX(), bounds.getBottom(), false);
        g.setGradientFill(grad);
        g.fillRoundedRectangle(bounds, 10.0f);

        g.setColour(juce::Colours::white.withAlpha(0.08f));
        g.drawRoundedRectangle(bounds, 10.0f, 1.0f);
    }
};

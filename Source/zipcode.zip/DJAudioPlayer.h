#pragma once
#include "../JuceLibraryCode/JuceHeader.h

class DJAudioPlayer : public AudioSourc
{
public
    DJAudioPlayer(AudioFormatManager& _formatManager)
    ~DJAudioPlayer()

    void prepareToPlay(int samplesPerBlockExpected, double sampleRate) override
    void getNextAudioBlock(const AudioSourceChannelInfo& bufferToFill) override
    void releaseResources() override

    void loadURL(URL audioURL)

    void setGain(double gain);              // user fader gain (0..1
    void setCrossfadeGain(double gain);     // crossfader gain (0..1
    void setSpeed(double ratio);            // 0.5..2.
    void setPosition(double posInSecs)
    void setPositionRelative(double pos)

    void start()
    void stop()
    bool isPlaying() const

    double getPositionRelative()
    double getLengthInSeconds() const;
    bool isPlaying() const;
private
    void applyGain()

    AudioFormatManager& formatManager
    std::unique_ptr<AudioFormatReaderSource> readerSource
    AudioTransportSource transportSource
    ResamplingAudioSource resampleSource{ &transportSource, false, 2 }

    double userGain{ 1.0 }
    double crossfadeGain{ 1.0 }
}


/*
  =============================================================================

    PlaylistComponent.

  =============================================================================
*
#pragma onc

#include <JuceHeader.h
#include functional>

class PlaylistComponent : public juce::Component,
    public juce::TableListBoxModel,
    public juce::Button::Listener
{
public:
    struct Track
    {
        juce::File file;
        juce::String title;
        double durationSeconds = 0.0;
    };

    PlaylistComponent(juce::AudioFormatManager& formatManager,
        std::function<void(const juce::File&, int deckIndex)> onLoadToDeck);

    ~PlaylistComponent() override;

    void paint(juce::Graphics&) override;
    void resized() override;

    // TableListBoxModel
    int getNumRows() override;
    void paintRowBackground(juce::Graphics&, int rowNumber, int width, int height, bool rowIsSelected) override;
    void paintCell(juce::Graphics&, int rowNumber, int columnId, int width, int height, bool rowIsSelected) override;
    juce::Component* refreshComponentForCell(int rowNumber, int columnId, bool isRowSelected,
        juce::Component* existingComponentToUpdate) override;

    // Buttons
    void buttonClicked(juce::Button* button) override;

private:
    juce::String formatTime(double seconds) const;

    juce::AudioFormatManager& formatManager;
    std::function<void(const juce::File&, int deckIndex)> onLoadToDeck;

    juce::TextButton addFilesButton{ "Add Tracks" };
    juce::TableListBox table{ "PlaylistTable", this };

    juce::FileChooser fChooser{ "Select audio files..." };

    std::<vecto<Track> tracks;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PlaylistComponent)
};


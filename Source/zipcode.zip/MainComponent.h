#pragma once

#include <JuceHeader.h>

#include "DJAudioPlayer.h"
#include "DeckGUI.h"
#include "PlaylistComponent.h"
#include "WaveformDisplay.h"
#include "DJLookAndFeel.h"

class MainComponent : public juce::AudioAppComponent,
    public juce::Slider::Listener,
    public juce::Timer
{
public:
    MainComponent();
    ~MainComponent() override;

    void prepareToPlay(int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill) override;
    void releaseResources() override;

    void paint(juce::Graphics& g) override;
    void resized() override;

    void sliderValueChanged(juce::Slider* slider) override;
    void timerCallback() override;

private:
    class VinylComponent : public juce::Component
    {
    public:
        void setSpinning(bool shouldSpin) { spinning = shouldSpin; }
        void advance(float delta) { if (spinning) angle += delta; }
        void paint(juce::Graphics& g) override;

    private:
        bool spinning = false;
        float angle = 0.0f;
    };

    void updateDeckInfoLabels();

    DJLookAndFeel djLookAndFeel;

    juce::AudioFormatManager formatManager;
    juce::AudioThumbnailCache thumbCache{ 200 };

    DJAudioPlayer player1;
    DJAudioPlayer player2;

    WaveformDisplay waveform1;
    WaveformDisplay waveform2;

    juce::Label deck1Info;
    juce::Label deck2Info;

    VinylComponent vinyl1;
    VinylComponent vinyl2;

    DeckGUI deckGUI1;
    DeckGUI deckGUI2;

    juce::MixerAudioSource mixerSource;
    juce::Slider crossfader;

    PlaylistComponent playlistComponent;

    juce::File deck1LastFile;
    juce::File deck2LastFile;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MainComponent)
};

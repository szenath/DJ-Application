/*
  ==============================================================================

    PlaylistComponent.cpp

  ==============================================================================
*/

#include "PlaylistComponent.h"

namespace
{
    enum Columns
    {
        colTitle = 1,
        colDuration = 2,
        colDeck1 = 3,
        colDeck2 = 4
    };

    class LoadToDeckButton : public juce::TextButton
    {
    public:
        LoadToDeckButton(const juce::String& text) : juce::TextButton(text) {}

        int row = -1;
        int deckIndex = 1;
    };
}

PlaylistComponent::PlaylistComponent(juce::AudioFormatManager& _formatManager,
    std::function<void(const juce::File&, int deckIndex)> _onLoadToDeck)
    : formatManager(_formatManager),
    onLoadToDeck(std::move(_onLoadToDeck))
{
    addAndMakeVisible(addFilesButton);
    addFilesButton.addListener(this);

    addAndMakeVisible(table);

    table.getHeader().addColumn("Track title", colTitle, 420, 100, 800, juce::TableHeaderComponent::defaultFlags);
    table.getHeader().addColumn("Duration", colDuration, 90, 60, 120, juce::TableHeaderComponent::defaultFlags);
    table.getHeader().addColumn("Deck 1", colDeck1, 90, 70, 120, juce::TableHeaderComponent::defaultFlags);
    table.getHeader().addColumn("Deck 2", colDeck2, 90, 70, 120, juce::TableHeaderComponent::defaultFlags);

    table.setRowHeight(32);
    table.getHeader().setStretchToFitActive(true);

    // Subtle look
    table.setColour(juce::ListBox::backgroundColourId, juce::Colours::transparentBlack);
    table.setOutlineThickness(0);
}

PlaylistComponent::~PlaylistComponent()
{
}

void PlaylistComponent::paint(juce::Graphics& g)
{
    auto bg = findColour(juce::ResizableWindow::backgroundColourId);
    g.setColour(bg.brighter(0.02f));
    g.fillRoundedRectangle(getLocalBounds().toFloat(), 10.0f);

    g.setColour(juce::Colours::white.withAlpha(0.08f));
    g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(1.0f), 10.0f, 2.0f);
}

void PlaylistComponent::resized()
{
    const int pad = 10;

    addFilesButton.setBounds(pad, pad, 140, 34);
    table.setBounds(pad, pad + 42, getWidth() - 2 * pad, getHeight() - (pad + 42) - pad);
}

int PlaylistComponent::getNumRows()
{
    return (int)tracks.size();
}

void PlaylistComponent::paintRowBackground(juce::Graphics& g, int rowNumber, int width, int height, bool rowIsSelected)
{
    if (rowIsSelected)
    {
        g.setColour(juce::Colours::deepskyblue.withAlpha(0.18f));
        g.fillRect(0, 0, width, height);
    }
    else if (rowNumber % 2 == 0)
    {
        g.setColour(juce::Colours::white.withAlpha(0.03f));
        g.fillRect(0, 0, width, height);
    }
}

void PlaylistComponent::paintCell(juce::Graphics& g, int rowNumber, int columnId, int width, int height, bool)
{
    if (rowNumber < 0 || rowNumber >= (int)tracks.size())
        return;

    const auto& t = tracks[(size_t)rowNumber];

    g.setColour(juce::Colours::white.withAlpha(0.85f));
    g.setFont(13.0f);

    if (columnId == colTitle)
    {
        g.drawText(t.title, 6, 0, width - 12, height, juce::Justification::centredLeft, true);
    }
    else if (columnId == colDuration)
    {
        g.drawText(formatTime(t.durationSeconds), 0, 0, width, height, juce::Justification::centred, true);
    }

    g.setColour(juce::Colours::white.withAlpha(0.06f));
    g.drawRect(0, 0, width, height, 1);
}

juce::Component* PlaylistComponent::refreshComponentForCell(int rowNumber, int columnId, bool,
    juce::Component* existingComponentToUpdate)
{
    if (columnId != colDeck1 && columnId != colDeck2)
        return nullptr;

    auto* btn = dynamic_cast<LoadToDeckButton*>(existingComponentToUpdate);

    if (btn == nullptr)
    {
        btn = new LoadToDeckButton(columnId == colDeck1 ? "Load" : "Load");
        btn->addListener(this);
    }

    btn->row = rowNumber;
    btn->deckIndex = (columnId == colDeck1 ? 1 : 2);

    return btn;
}

juce::String PlaylistComponent::formatTime(double seconds) const
{
    if (seconds <= 0 || std::isnan(seconds) || std::isinf(seconds))
        return "--:--";

    int s = (int)std::round(seconds);
    int mins = s / 60;
    int secs = s % 60;

    return juce::String(mins) + ":" + juce::String(secs).paddedLeft('0', 2);
}

void PlaylistComponent::buttonClicked(juce::Button* button)
{
    if (button == &addFilesButton)
    {
        auto flags = juce::FileBrowserComponent::canSelectFiles
            | juce::FileBrowserComponent::openMode
            | juce::FileBrowserComponent::canSelectMultipleItems;

        fChooser.launchAsync(flags, [this](const juce::FileChooser& chooser)
            {
                auto results = chooser.getResults();
                if (results.isEmpty())
                    return;

                for (auto& f : results)
                {
                    if (!f.existsAsFile())
                        continue;

                    // Avoid duplicates
                    bool exists = false;
                    for (auto& t : tracks)
                        if (t.file == f) { exists = true; break; }
                    if (exists) continue;

                    Track t;
                    t.file = f;
                    t.title = f.getFileNameWithoutExtension();

                    // Duration
                    if (auto stream = std::unique_ptr<juce::FileInputStream>(f.createInputStream()))
                    {
                        if (auto* reader = formatManager.createReaderFor(std::move(stream)))
                        {
                            t.durationSeconds = (double)reader->lengthInSamples / reader->sampleRate;
                            delete reader;
                        }
                    }

                    tracks.push_back(std::move(t));
                }

                table.updateContent();
                table.repaint();
            });

        return;
    }

    if (auto* loadBtn = dynamic_cast<LoadToDeckButton*>(button))
    {
        if (loadBtn->row < 0 || loadBtn->row >= (int)tracks.size())
            return;

        const auto& t = tracks[(size_t)loadBtn->row];
        if (onLoadToDeck)
            onLoadToDeck(t.file, loadBtn->deckIndex);
    }
}

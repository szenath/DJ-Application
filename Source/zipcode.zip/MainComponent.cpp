/*
  ==============================================================================

    MainComponent.cpp

  ==============================================================================
*/

#include "MainComponent.h"

void MainComponent::VinylComponent::paint(juce::Graphics& g)
{
    auto b = getLocalBounds().toFloat();
    auto r = b.reduced(6.0f);
    auto centre = r.getCentre();
    auto radius = juce::jmin(r.getWidth(), r.getHeight()) * 0.5f;

    g.setColour(juce::Colours::black.withAlpha(0.78f));
    g.fillEllipse(centre.x - radius, centre.y - radius, radius * 2, radius * 2);

    g.setColour(juce::Colours::white.withAlpha(0.15f));
    g.drawEllipse(centre.x - radius, centre.y - radius, radius * 2, radius * 2, 4.0f);

    g.setColour(juce::Colours::white.withAlpha(0.06f));
    for (int i = 0; i < 10; ++i)
    {
        float rr = radius * (0.25f + i * 0.07f);
        g.drawEllipse(centre.x - rr, centre.y - rr, rr * 2, rr * 2, 1.0f);
    }

    float labelR = radius * 0.22f;
    g.setColour(juce::Colours::darkgrey.withAlpha(0.92f));
    g.fillEllipse(centre.x - labelR, centre.y - labelR, labelR * 2, labelR * 2);

    g.setColour(juce::Colours::silver.withAlpha(0.9f));
    g.fillEllipse(centre.x - 3, centre.y - 3, 6, 6);

    // rotating marker line
    juce::Path p;
    auto a = angle;
    auto end = centre + juce::Point<float>(std::cos(a), std::sin(a)) * (radius * 0.85f);
    p.startNewSubPath(centre);
    p.lineTo(end);

    g.setColour(juce::Colours::white.withAlpha(0.22f));
    g.strokePath(p, juce::PathStrokeType(3.0f));
}

MainComponent::MainComponent()
    : player1(formatManager),
    player2(formatManager),
    waveform1(formatManager, thumbCache),
    waveform2(formatManager, thumbCache),
    deckGUI1(&player1, &waveform1, [this](const juce::File& f) { deck1LastFile = f; updateDeckInfoLabels(); }),
    deckGUI2(&player2, &waveform2, [this](const juce::File& f) { deck2LastFile = f; updateDeckInfoLabels(); }),
    playlistComponent(formatManager,
        [this](const juce::File& f, int deckIndex)
        {
            if (deckIndex == 1)
            {
                player1.loadURL(juce::URL{ f });
                waveform1.loadURL(juce::URL{ f });
                deck1LastFile = f;
            }
            else
            {
                player2.loadURL(juce::URL{ f });
                waveform2.loadURL(juce::URL{ f });
                deck2LastFile = f;
            }
            updateDeckInfoLabels();
        })
{
    setLookAndFeel(&djLookAndFeel);

    setSize(1100, 720);

    if (juce::RuntimePermissions::isRequired(juce::RuntimePermissions::recordAudio)
        && !juce::RuntimePermissions::isGranted(juce::RuntimePermissions::recordAudio))
    {
        juce::RuntimePermissions::request(juce::RuntimePermissions::recordAudio,
            [&](bool granted) { if (granted)  setAudioChannels(2, 2); });
    }
    else
    {
        setAudioChannels(0, 2);
    }

    formatManager.registerBasicFormats();

    addAndMakeVisible(deckGUI1);
    addAndMakeVisible(deckGUI2);

    addAndMakeVisible(waveform1);
    addAndMakeVisible(waveform2);

    addAndMakeVisible(deck1Info);
    addAndMakeVisible(deck2Info);

    addAndMakeVisible(vinyl1);
    addAndMakeVisible(vinyl2);

    addAndMakeVisible(playlistComponent);

    addAndMakeVisible(crossfader);
    crossfader.setName("crossfader");
    crossfader.setSliderStyle(juce::Slider::LinearHorizontal);
    crossfader.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    crossfader.setRange(0.0, 1.0, 0.001);
    crossfader.setValue(0.5);
    crossfader.addListener(this);

    auto styleLabel = [](juce::Label& l)
        {
            l.setJustificationType(juce::Justification::centred);
            l.setFont(juce::Font(14.0f, juce::Font::bold));
            l.setColour(juce::Label::textColourId, juce::Colours::white.withAlpha(0.88f));
            l.setInterceptsMouseClicks(false, false);
        };

    styleLabel(deck1Info);
    styleLabel(deck2Info);

    updateDeckInfoLabels();

    startTimerHz(30);

    sliderValueChanged(&crossfader);
}

MainComponent::~MainComponent()
{
    shutdownAudio();
    setLookAndFeel(nullptr);
}

void MainComponent::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    player1.prepareToPlay(samplesPerBlockExpected, sampleRate);
    player2.prepareToPlay(samplesPerBlockExpected, sampleRate);

    mixerSource.addInputSource(&player1, false);
    mixerSource.addInputSource(&player2, false);
    mixerSource.prepareToPlay(samplesPerBlockExpected, sampleRate);
}

void MainComponent::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    mixerSource.getNextAudioBlock(bufferToFill);
}

void MainComponent::releaseResources()
{
    player1.releaseResources();
    player2.releaseResources();
    mixerSource.releaseResources();
}

void MainComponent::paint(juce::Graphics& g)
{
    g.fillAll(getLookAndFeel().findColour(juce::ResizableWindow::backgroundColourId));
}

void MainComponent::resized()
{
    const int pad = 12;
    const int topH = (int)(getHeight() * 0.55);

    const int sideW = 190;
    deckGUI1.setBounds(pad, pad, sideW, topH - 2 * pad);
    deckGUI2.setBounds(getWidth() - pad - sideW, pad, sideW, topH - 2 * pad);

    const int centreX = deckGUI1.getRight() + pad;
    const int centreW = deckGUI2.getX() - pad - centreX;

    const int infoH = 26;
    const int waveH = 70;

    deck1Info.setBounds(centreX, pad, centreW / 2 - pad / 2, infoH);
    deck2Info.setBounds(centreX + centreW / 2 + pad / 2, pad, centreW / 2 - pad / 2, infoH);

    waveform1.setBounds(centreX, pad + infoH + 6, centreW / 2 - pad / 2, waveH);
    waveform2.setBounds(centreX + centreW / 2 + pad / 2, pad + infoH + 6, centreW / 2 - pad / 2, waveH);

    const int crossW = 340;
    const int crossH = 28;
    const int crossY = pad + infoH + 6 + waveH + 18;
    crossfader.setBounds((getWidth() - crossW) / 2, crossY, crossW, crossH);

    // vinyls
    const int vinylSize = 250;
    const int vinylY = crossY + crossH + 18;

    vinyl1.setBounds(centreX, vinylY, vinylSize, vinylSize);
    vinyl2.setBounds(centreX + centreW - vinylSize, vinylY, vinylSize, vinylSize);

    playlistComponent.setBounds(pad, topH, getWidth() - 2 * pad, getHeight() - topH - pad);
}

void MainComponent::sliderValueChanged(juce::Slider* slider)
{
    if (slider == &crossfader)
    {
        const double x = crossfader.getValue(); // 0..1

        const double leftGain = std::cos(x * juce::MathConstants<double>::halfPi);
        const double rightGain = std::sin(x * juce::MathConstants<double>::halfPi);

        player1.setCrossfadeGain(leftGain);
        player2.setCrossfadeGain(rightGain);
    }
}

static juce::String formatTimeMMSS(double seconds)
{
    if (seconds <= 0 || std::isnan(seconds) || std::isinf(seconds))
        return "--:--";

    int s = (int)std::round(seconds);
    int mins = s / 60;
    int secs = s % 60;

    return juce::String(mins) + ":" + juce::String(secs).paddedLeft('0', 2);
}

void MainComponent::updateDeckInfoLabels()
{
    auto makeInfo = [](const juce::File& f, DJAudioPlayer& p)
        {
            if (!f.existsAsFile())
                return juce::String("No track loaded");

            auto title = f.getFileNameWithoutExtension();
            auto len = p.getLengthInSeconds();
            return title + "   " + formatTimeMMSS(len);
        };

    deck1Info.setText(makeInfo(deck1LastFile, player1), juce::dontSendNotification);
    deck2Info.setText(makeInfo(deck2LastFile, player2), juce::dontSendNotification);
}

void MainComponent::timerCallback()
{
    waveform1.setPositionRelative(player1.getPositionRelative());
    waveform2.setPositionRelative(player2.getPositionRelative());

    vinyl1.setSpinning(player1.isPlaying());
    vinyl2.setSpinning(player2.isPlaying());

    vinyl1.advance(0.20f);
    vinyl2.advance(0.20f);

    vinyl1.repaint();
    vinyl2.repaint();
}
